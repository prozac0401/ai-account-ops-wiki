# 문서별 보완 목록

기준: 2026-09-06 조회, 저장소 main `a095709…`의 본문 32개. 경로는 `public/content/` 기준이다. G번호는 반영 추적용이며 위키 제목에 붙이는 번호가 아니다.

상태: **누락**은 해당 구체 내용이 없음, **부분**은 기본 설명에 보완 필요, **정정**은 오류·적용 범위·현재 정책 수정 필요, **확인**은 원문이나 현장 근거 확보 후 단정 가능함을 뜻한다. 우선순위 P0는 과금·권한·회수·공개 범위, P1은 반복 운영·인수인계, P2는 연혁·확장 조사다.

## 공통 운영

| ID · 우선 | 상태 | 반영 위치 | 추가하거나 고칠 내용 | 근거·자료 |
|---|---|---|---|---|
| G01 · P1 | 정정 | `00_운영_배경.md` | 도입 순서를 Cursor → Google Workspace·Colab → 다른 AI 서비스로 정리; 사용자의 4/24 정정 반영 | C01, 07 |
| G02 · P1 | 부분 | `Home.md`, `01_운영_원칙.md` | 매뉴얼과 백서의 용도, 적용 플랜·기준일·문서 책임자·변경 이력 | 07, 14 |
| G03 · P1 | 부분 | `02_서비스_전체_지도.md`, `04_계정_생명주기.md` | 42 수강생/001–042, 49계정/00–48, 48 PC 등 집계 대상을 구분; 전역 정원으로 합치지 않음 | C08, C12–C15, F02–F08 |
| G04 · P1 | 부분 | `03_역할과_책임.md`, `education/교육담당자_운영_가이드.md` | 작업별 최종 책임 A, 외부 강사·업체 요청 경로, 대리자·인수인계 완료 증거를 제안 | R01, 07, 14 |

## Cursor

| ID · 우선 | 상태 | 반영 위치 | 추가하거나 고칠 내용 | 근거·자료 |
|---|---|---|---|---|
| G05 · P0 | 정정 | `services/Cursor.md`, `billing/Cursor_과금.md` | 역할과 Standard/Premium/Free 좌석 유형을 구분; 2026년 6월 이후 정책 적용 여부 | P01–P02, 03 |
| G06 · P0 | 누락 | `billing/Cursor_과금.md`, `glossary.md` | Cursor Models/Other Models 두 풀, 풀 잔액과 on-demand 구분, 외부 모델 Token Rate | P02, P06, 03 |
| G07 · P0 | 누락 | `services/Cursor.md`, `education/수강생_주의사항.md` | Cost만 허용·Hard Auto 운영 기록과 실제 의미; 고정 모델·추가 과금 0으로 오해하지 않음 | C15, F19–F20, P04, 03 |
| G08 · P0 | 부분 | `billing/Cursor_과금.md` | Only Admins Can Edit Usage Settings, 팀 한도, 집행 지연·임시 크레딧 | P03, 03 |
| G09 · P0 | 정정 | `billing/Cursor_과금.md`, `billing/실제_비용과_True_up.md` | Enterprise legacy Auto Cost의 2026-09-07 경계와 일반 Teams 구분; 반영 시 재조회 | P04–P05 |
| G10 · P1 | 정정 | `services/Cursor.md`, `billing/Cursor_과금.md`, Q&A 관련 부분 | Max Mode 설명을 legacy request-based 플랜 범위로 한정 | P05, 03 |
| G11 · P1 | 누락 | `billing/Cursor_과금.md` | 42명×$10=$420는 팀 예산 가정; 개인별 강제 제한·청구 실적과 구분 | C15, P03, 03 |
| G12 · P0 | 누락 | 신규 `issues/Cursor_청구_크레딧_분쟁.md` | 6월 청구서 대조법, 잔액 원장 요구, 0232·0233 최종 미확인 상태 | C06–C07, F09–F13, 13 |
| G13 · P0 | 누락 | 위 신규 이슈, `04_계정_생명주기.md` | 장래 취소 의사·즉시 해지·팀 삭제·접근 불가를 구분; 복구 요청 조건 기록 | C07, 13 |
| G14 · P1 | 부분 | `billing/Cursor_과금.md` | 과거 usage 사용자/removed 멤버와 현재 유료 좌석 구분; Admin API 금액 필드 범위 | C04, P07, 03 |
| G15 · P1 | 누락 | 신규 `issues/AI_서비스_장애_초동대응.md` | provider 연결 불가·high load·계정 불일치의 분류, 제한된 재시도와 증거 수집 | C16, 03, 14 |
| G16 · P1 | 정정 | `services/Cursor.md`, `billing/Cursor_과금.md` | invoice PDF 제공과 invoice 방식 결제를 구분; Enterprise 최소 150명 조건 근거 확인 | R01, P02, 03, U08 |

## Google Workspace·Colab

| ID · 우선 | 상태 | 반영 위치 | 추가하거나 고칠 내용 | 근거·자료 |
|---|---|---|---|---|
| G17 · P0 | 누락 | `services/Google_Workspace_및_Colab.md` | Google Pay 서비스 ON과 OU 확인; OR-AC-01 시 점검 경로 | F17–F18, 04 |
| G18 · P0 | 누락 | 신규 `billing/Colab_PAYG_결제_프로필.md` | 비즈니스 프로필 임시 초대 → 구매 권한 → 수락 → 계정별 PAYG 결제 | F18, F22, 04 |
| G19 · P0 | 누락 | 위 신규 문서, `04_계정_생명주기.md` | 구매·증빙 확보 후 프로필 권한 회수; CU 유지·관리자 영수증 접근은 현장 확인 조건 | F07, F17–F18, 04, U04–U05 |
| G20 · P1 | 누락 | 위 신규 문서, 자동화 문서 | 계정마다 카드 저장하던 구안과 임시 결제 프로필 공유 최신 요구를 구분 | F07–F08, C08 |
| G21 · P1 | 누락 | 신규 `services/Colab_CU와_런타임_운영.md` | CU 원문·수치·시각·증감 요인·수집 상태를 누적 기록; 만료/신규 부여와 사용량 혼동 방지 | F07, 04, 14 |
| G22 · P0 | 확인 | 위 신규 문서, `billing/Google_Workspace_Colab_과금.md` | 라이선스 해제 후 기존 CU 처리 규칙은 미확인으로 유지; 지원 답변/전후 화면 확보 | C10, P10, U04 |
| G23 · P1 | 확인 | 위 신규 문서 | Workspace 22일/Colab 1일이라는 기억을 계정별 주기표에서 검증; 보편 규칙 금지 | C11, U06 |
| G24 · P1 | 부분 | `billing/Google_Workspace_Colab_과금.md` | 조직 Colab과 개인 구독 CU 합산 가능, 개인 구독을 조직 관리자가 관리할 수 없다는 경계 | P09, 04 |
| G25 · P0 | 누락 | `services/Colab_CU와_런타임_운영.md` | 잔액 조회와 런타임 종료를 별도 동작으로 정의; 조회 과정에서 런타임 생성 방지 | F06–F07, 04 |

## 자동화·배포

| ID · 우선 | 상태 | 반영 위치 | 추가하거나 고칠 내용 | 근거·자료 |
|---|---|---|---|---|
| G26 · P0 | 누락 | 신규 `automation/Colab_Manager_운영.md` | V2·V3 독립 N≥2→0 시험, 사이클마다 1 감소, 불명확하면 HOLD; 체크리스트는 미기입 | F06, 05 |
| G27 · P1 | 누락 | 위 신규 문서 | 버전·실제 포함 기능·목표 기능 구분; Gmail EML 자동 보관을 구현 완료로 쓰지 않음 | F06–F07, 05 |
| G28 · P0 | 누락 | 신규 `automation/강의장_계정_초기화.md` | Reset 00–48의 넓은 삭제 범위와 Cursor 001–042 V3 선택적 쿠키 정리·권한 차이 | F01–F03, F14–F16, 05 |
| G29 · P0 | 누락 | 위 신규 문서, 수강생 안내 | 로그인 키 입력 후 실제 Cursor 앱 계정을 눈으로 확인; 브라우저 성공과 앱 계정 불일치 | F02–F03, C13, 05 |
| G30 · P1 | 확인 | 위 신규 문서 | `__AI_EDU__` 백업·복원 및 W키 동작은 버전 대응 원본 추가 확보 후 반영 | C14, U11 |
| G31 · P0 | 누락 | 신규 `automation/비밀번호_교체.md`, 보안 문서 | v0.3의 with-secrets 파일을 의도된 과거 설계로 기록; 공개용 비식별 로그 분리·보관 책임 | F04–F05, 05, 08 |
| G32 · P1 | 누락 | 신규 `automation/도구_배포와_검증.md` | Drive ZIP/EXE 다운로드 관찰, Zone.Identifier·SmartScreen·서명·해시 구분 | C19, P20, 05 |
| G33 · P2 | 확인 | 위 신규 문서 | 48 PC·공유 연결 제약과 MQTT/UDP 제안의 도입 상태; IP만으로 원격 수신 가능 단정 금지 | C12, U12 |
| G34 · P1 | 부분 | 위 신규 문서 | 시작 시 1회 실행·자기삭제 배포의 버전/실행 결과 확인 항목; 실제 적용 여부 미확인 | C14, 05 |

## 다른 AI·위키 관리

| ID · 우선 | 상태 | 반영 위치 | 추가하거나 고칠 내용 | 근거·자료 |
|---|---|---|---|---|
| G35 · P1 | 부분 | `services/ChatGPT_Business.md` | 일반 멤버의 초대 권한·pending/accepted 비용 시점은 현재 워크스페이스와 공식 문서로 검증 | C02–C03, U09 |
| G36 · P0 | 부분 | `billing/ChatGPT_OpenAI_API_과금.md` | Codex의 워크스페이스 크레딧과 API key 비용 분리; 신규/legacy 좌석 종류의 실제 계약 확인 | C17, P14, 06 |
| G37 · P0 | 정정 | `services/OpenAI_API.md`, 과금·보안 문서 | spend alert / hard limit / usage tier / rate limit 분리, 429 원인별 처리, OT 앱 키·자료 경계 | P16–P17, F21, 06 |
| G38 · P1 | 부분 | `services/Claude_Business.md`, 신규 `billing/Claude_과금.md` | 팀 좌석 감소 메뉴·갱신 시점, 별도 API 결제와 Word LLM Evaluator 계획의 상태 | P21–P23, C21, 06 |
| G39 · P1 | 누락 | `services/Claude_Business.md`, Q&A | 자동 모델 전환 설정·실제 응답 라벨·API fallback을 구분; 과거 모델 실행은 미확정 | C20, P24, 06 |
| G40 · P2 | 확인 | `02_서비스_전체_지도.md` 또는 백서 부록 | AWS·GCP·Knox 등 인접 도구는 계정/결제 관계를 확인할 조사 목록으로만 추가 | C22, U15 |
| G41 · P0 | 부분 | 신규 `operations/위키_유지보수.md`, 정보보안 문서 | main과 실제 Azure 배포 연결 확인; 로그인·허용 역할·정적 원문·공개 GitHub 경로 분리 | R01–R03, C23, P18–P19, 08, 12 |
| G42 · P0 | 부분 | `SOURCES.md`, 컴플라이언스 문서 | 주장별 출처 ID·확인일·원본/요약 등급, 민감 원본 공개 제외 | 08–09, 14 |
| G43 · P1 | 부분 | `templates/` | 비용 대조, CU, 회수, 변경, 시험, 인수인계, 지원 문의 기록 양식 | 14 |
| G44 · P1 | 정정 | `billing/실제_비용과_True_up.md` | “기본 10석: 13석×$25” 표기 수정; 사용월 $300·다음달 기본 $325·합산 청구 예시 $375 구분 | R01, 06 |
| G45 · P1 | 부분 | `src/main.js`, Home, PAGE_TREE, _Sidebar, SOURCES | 새 문서 docs/sections 등록·검색·내부 링크 검증; 기존 ../Home 등 링크 처리도 확인 | R02–R03, 12 |

## 이미 있는 내용은 보존한다

Cloud Identity와 Business Starter 분리, 자동 라이선스 주의, Colab 서비스 ON과 라이선스 별도 처리, 온라인/파트너 계약 차이, 계정 생명주기, 기본 개인정보·삭제·사고 대응, Cursor 4월 표시 오류 해결, Claude 멤버 제거와 좌석 감소의 차이는 이미 있다. 이 주제 전체를 누락으로 취급해 중복 문서를 만들지 않는다. 구체적인 새 절차·근거·버전 차이를 기존 문서에 연결한다.
