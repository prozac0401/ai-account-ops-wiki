# AI 계정 운영 위키 보완 자료

작성 기준일: 2026-09-06 UTC · 상태: 담당자 검토 및 Codex 반영용 초안

목적은 Cursor에서 시작해 Google Workspace·Colab, ChatGPT·Codex·OpenAI API, Claude 등으로 확대된 교육 계정 운영 경험을 공식 담당자 업무매뉴얼과 백서로 정리하는 것이다. 이 묶음은 현재 위키와 대조한 **45개 보완 항목**, 출처, 업무 절차 초안, 미확인 사항, Codex 작업 지시문을 제공한다. 저장소는 이번 작업에서 수정하지 않았다.

45개는 구체 내용 누락 19개, 부분 보완 14개, 정정 7개, 추가 확인 5개다. 우선순위는 P0 20개, P1 23개, P2 2개로 나눴다. 확정에 필요한 추가 질문 18개도 별도로 정리했다.

## 먼저 읽을 파일

1. [01_GAP_MATRIX.md](01_GAP_MATRIX.md): 무엇을 어느 문서에 반영할지 확인한다.
2. [11_CODEX_PROMPT.md](11_CODEX_PROMPT.md): 묶음 전체를 Codex에 제공한 뒤 이 지시문으로 반영을 요청한다.
3. [10_UNRESOLVED.md](10_UNRESOLVED.md): 원문·최종 결과·현장 확인이 필요한 항목을 확인한다.

## 조사 범위와 한계

| 구분 | 확인 범위 |
|---|---|
| 비교 저장소 | [prozac0401/ai-account-ops-wiki](https://github.com/prozac0401/ai-account-ops-wiki) |
| 비교 기준 | main, `a09570913697213fb34a95c62d0f0cae5864647a` |
| 기준 커밋 시각 | 2026-04-28 11:32 UTC |
| 위키 본문 | `public/content` 아래 Markdown 32개 전체 |
| 구조 확인 | 본문 포함 39개 파일: 문서 등록, 스타일 지침, 빌드·배포 설정 등 |
| 과거 대화 | 2025년부터 2026-09-06까지 관련 주제를 17개 검색 질의로 탐색; 질의 수는 대화 수가 아니다 |
| 보관 자료 | 청구서 PDF, Google 지원 EML, 자동화 설계·배포 ZIP/README, 설정 화면 등 22개 자료 항목 |
| 현재 정책 | 서비스 제공자 공식 문서를 2026-09-06에 조회하여 별도 대조 |

전체 채팅 내보내기, 전체 대화 목록, 모든 원문 링크는 확보하지 못했다. 따라서 이 묶음은 **검색으로 발견하고 확인할 수 있었던 범위의 보완 목록**이며, 모든 대화를 빠짐없이 회수했다는 의미가 아니다. 검색 요약에 나온 과거 AI 설명은 실제 실행 결과나 공식 정책으로 승격하지 않았다. 현재 배포된 사이트와 조회한 main이 같은 버전인지도 별도 확인이 필요하다.

## 파일 구성

| 파일 | 용도 |
|---|---|
| [01_GAP_MATRIX.md](01_GAP_MATRIX.md) | G01–G45 누락·부분 보완·정정·확인 필요 목록 |
| [02_CONVERSATION_EVIDENCE.md](02_CONVERSATION_EVIDENCE.md) | 회수된 대화 주제, 날짜, 근거 강도, 상충 지점 |
| [03_CURSOR_OPERATIONS.md](03_CURSOR_OPERATIONS.md) | 좌석·사용량·Router·예산·장애·청구 분쟁 절차 |
| [04_GOOGLE_WORKSPACE_COLAB.md](04_GOOGLE_WORKSPACE_COLAB.md) | PAYG 결제 프로필, CU 수집, 라이선스·회수 절차 |
| [05_AUTOMATION_AND_DISTRIBUTION.md](05_AUTOMATION_AND_DISTRIBUTION.md) | 자동화 버전, 현장 시험, 비밀번호·배포 이력 |
| [06_CHATGPT_CLAUDE_API.md](06_CHATGPT_CLAUDE_API.md) | ChatGPT·Codex·API·Claude 및 인접 도구 범위 |
| [07_MANUAL_AND_WHITEPAPER_STRUCTURE.md](07_MANUAL_AND_WHITEPAPER_STRUCTURE.md) | 매뉴얼/백서 구성, 책임·인수인계 기준 제안 |
| [08_EVIDENCE_AND_PUBLICATION.md](08_EVIDENCE_AND_PUBLICATION.md) | 원본 관리와 공개 가능한 요약의 구분 |
| [09_OFFICIAL_SOURCES.md](09_OFFICIAL_SOURCES.md) | R/F/P 출처 목록, 링크, 확인 범위 |
| [10_UNRESOLVED.md](10_UNRESOLVED.md) | 추가 확보할 원문과 확인 방법·담당 역할 |
| [11_CODEX_PROMPT.md](11_CODEX_PROMPT.md) | 다음 Codex 세션에 전달할 작업 지시문 |
| [12_REPO_AUDIT.md](12_REPO_AUDIT.md) | 실제 파일별 점검 결과와 문서 등록 방법 |
| [13_INTERNAL_CASE_NOTES.md](13_INTERNAL_CASE_NOTES.md) | 내부 검토용 청구·지원 사건별 증거 정리 |
| [14_OPERATIONS_TEMPLATES.md](14_OPERATIONS_TEMPLATES.md) | 현장에서 복사할 운영 기록 양식 |
| [source_manifest.json](source_manifest.json) | 확인 자료의 파일명·해시·기준본을 담은 출처 대장 |

## 반영 순서

**P0부터 반영한다.** 과금·권한·계정 회수에 직접 영향을 주는 Cursor 사용량 정책, Google 결제 프로필 흐름, API 예산 통제, 비밀정보 포함 로그의 취급, 청구 분쟁 상태를 먼저 보완한다. 다음으로 자동화 현장 절차와 업무 인수인계 기준을 반영한다. 마지막으로 백서 연혁과 인접 도구의 조사 항목을 정리한다.

각 문장은 `공식 확인`, `원본 자료 확인`, `대화에서 회수`, `설계·제안`, `확인 필요` 중 해당하는 상태를 유지한다. 공식 문서가 존재해도 특정 조직 계정에서 설정·결제·복구가 완료됐다는 증거는 되지 않는다. 절차 초안의 담당 역할·주기·완료 기준은 조직이 채택할 운영안이며 기존 사규로 단정하지 않는다.

공개 저장소에 반영할 때는 일반화한 절차와 비식별 사례 요약을 사용한다. 원본 EML/PDF, 계정·결제정보가 든 실행 파일, 비밀번호 포함 로그는 이 묶음에 재수록하지 않았다. 13번 파일은 사건 금액과 지원 건 식별자를 담은 내부 검토용이므로 그대로 공개하지 않는다.

## 특히 주의할 결론

- Cursor의 4월 Unpaid Admin 표시 오류 해결 기록과 6–7월 청구·팀 접근 분쟁은 별도 사건이다. 후자의 최종 해결은 확인되지 않았다.
- Google 지원은 비즈니스 결제 프로필 공유 절차를 안내했다. 49계정 전체 구매·회수·잔여 CU 유지까지 검증했다는 뜻은 아니다.
- 자동화 설계서와 체크리스트가 존재한다. 빈 체크리스트를 현장 시험 합격 기록으로 사용하지 않는다.
- Cursor Auto·Max Mode·사용량 풀은 플랜과 적용일에 따라 다르다. 2026-09-07 경계 정책은 반영일에 다시 확인한다.
- OpenAI API는 현재 spend alert와 hard spend limit를 구분한다. 과거의 “예산은 모두 알림일 뿐”이라는 설명도 그대로 재사용하면 안 된다.
