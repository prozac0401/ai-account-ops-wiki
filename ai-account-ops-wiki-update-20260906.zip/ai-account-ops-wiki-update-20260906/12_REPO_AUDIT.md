# 저장소 기준본과 통합 위치 점검

기준 저장소: [ai-account-ops-wiki](https://github.com/prozac0401/ai-account-ops-wiki)

조회일: 2026-09-06 UTC · main 커밋: `a09570913697213fb34a95c62d0f0cae5864647a` · 커밋 시각: 2026-04-28 11:32 UTC · 커밋 메시지: “Move Cursor Unpaid Admin note into issues section”.

이번 작업은 기준본 읽기와 자료 작성이다. 저장소 수정·build·실제 사이트 배포 시험은 하지 않았다. 다음 Codex가 현재 checkout·remote·배포본을 확인한 뒤 반영한다.

## 실제 프로젝트 구조

| 항목 | 확인 결과 |
|---|---|
| 본문 | `public/content` 아래 Markdown 32개 |
| 앱 등록 문서 | `src/main.js`의 docs에 29개 |
| 등록하지 않은 본문 관리 파일 | `PAGE_TREE.md`, `README.md`, `_Sidebar.md` 3개. 관리용 파일이므로 자동으로 누락 문서라 판단하지 않음 |
| 탐색 | docs와 sections 명시 배열, 바로가기·서비스 칩·우선 문서 등 별도 구성 |
| 문서 읽기 | `fetchDoc`가 `content/` + 인코딩한 file 경로를 fetch |
| 검색 | 등록 docs의 본문을 읽어 검색 색인을 구성 |
| 빌드 | Vite, `npm run build` = `vite build`, base `./` |
| 확인한 배포 설정 | `.github/workflows/deploy-pages.yml`: main 변경에서 빌드해 gh-pages에 게시하는 흐름 |
| Azure 설정 | 기준 트리에서 Azure workflow·`staticwebapp.config.json` 확인되지 않음 |
| package의 private | npm 게시 관련 플래그. GitHub·사이트 접근 통제를 의미하지 않음 |

이 프로젝트를 GitHub의 별도 `.wiki.git` 저장소로 오인해 작업하지 않는다. 운영 문서는 앱의 정적 자산이며 파일 추가와 앱 등록을 함께 처리한다.

## 기존 본문 32개와 보완 연결

아래 경로는 모두 `public/content/` 기준이다. 이미 있는 내용은 읽고 보존하며 추가할 구체 항목만 연결한다.

| 기존 파일 | 확인한 기반 내용 | 보완 G번호 |
|---|---|---|
| `00_운영_배경.md` | 계정 운영 배경·도구 확대 | G01–G02 |
| `01_운영_원칙.md` | 권한·비용·안내·회수 기본 원칙 | G02, G42 |
| `02_서비스_전체_지도.md` | 서비스별 운영 관계 | G03, G40 |
| `03_역할과_책임.md` | 운영·교육·결제·보안 역할과 RACI | G04 |
| `04_계정_생명주기.md` | 발급·배정·사용·회수 | G03, G13, G19, G25, G43 |
| `Home.md` | 홈·문서 탐색 | G02, G45 |
| `PAGE_TREE.md` | 문서 트리 | G45 |
| `README.md` | content 폴더 안내 | G45 |
| `SOURCES.md` | 출처 목록 | G42, G45 |
| `_Sidebar.md` | 사이드바 안내 | G45 |
| `glossary.md` | 기존 용어 설명 | G05–G10, G21, G37 |
| `services/Cursor.md` | 팀·역할·Privacy Mode·4월 표시 오류 | G05, G07, G10, G14–G16 |
| `services/Google_Workspace_및_Colab.md` | Cloud Identity·라이선스·서비스·로그인·회수 | G17–G25 |
| `services/ChatGPT_Business.md` | 워크스페이스 운영 | G35–G36 |
| `services/OpenAI_API.md` | 조직·프로젝트·키·예산 운영 | G37 |
| `services/Claude_Business.md` | Claude 사용·보안·보존 범위 | G38–G39 |
| `billing/과금_전체_지도.md` | 과금 분류 | G06, G18, G24, G36–G38 |
| `billing/Cursor_과금.md` | Teams $40·좌석·크레딧·사용량·4월 이슈 링크 | G05–G16 |
| `billing/Google_Workspace_Colab_과금.md` | 계약·월/연·라이선스와 비용 | G18–G24 |
| `billing/ChatGPT_OpenAI_API_과금.md` | ChatGPT/Codex 좌석·크레딧과 API 분리 | G35–G37 |
| `billing/실제_비용과_True_up.md` | 기준일 가격·일할·갱신·Claude 좌석 감소 | G05, G09, G16, G38, G44 |
| `billing/해외_결제_차단_대응.md` | 카드·해외 결제 차단·증빙 기본 대응 | G12, G17–G19 연결만 보완 |
| `issues/Cursor_Unpaid_Admin_표시_오류_대응.md` | 2026-04-25~26 표시 오류, 4/28 복구 확인 기록 | 보존; G12의 후속 분쟁을 별도 문서로 연결 |
| `compliance/개인정보_고지_동의.md` | 고지·동의·책임 | G31, G37, G42의 실제 처리 항목 연결 |
| `compliance/데이터_리텐션_삭제.md` | 보관·삭제 기본 기준 | G19, G25, G28, G31, G42 |
| `compliance/사고_대응.md` | 사고 초동·증거·후속 대응 | G12–G15, G37, G42 |
| `compliance/정보보안_검토.md` | 서비스 보안 검토 | G31–G32, G37, G41–G42 |
| `education/교육담당자_운영_가이드.md` | 교육 전·중·후 운영 | G04, G07, G25–G29, G43 |
| `education/수강생_주의사항.md` | 계정·비용·자료 사용 안내 | G07, G11, G25, G29 |
| `qna/현장_실제_QA.md` | 실제 질문과 4월 이슈 답변 | G10, G19, G22–G24, G35, G39 |
| `templates/개인정보_고지서_동의서.md` | 고지·동의 양식 | G31, G37의 실제 데이터 범위 확인 후 연결 |
| `templates/수강생_안내문.md` | 수강생 안내 양식 | G07, G11, G25, G29 |

## 구체적으로 찾지 못한 내용

전문 대조에서 PAYG 프로필 절차, 0232/0233 후속 분쟁, 두 Cursor 사용량 풀·Token Rate·Router 운영, B113 Colab Manager, 복수 런타임 검수, Zone.Identifier 배포 사례 등의 구체 내용은 확인되지 않았다. 이는 해당 절차의 누락 판단이며, 모든 계정·과금 원칙이 없다는 뜻은 아니다.

Google 초기 2개 라이선스·50% 선납 등 이미 개별 경험으로 한정한 부분은 일반 정책처럼 다시 쓰지 않는다. Claude의 멤버 제거/좌석 총량 감소 차이는 기존 실제 비용 문서에 있으므로 별도 과금 페이지에는 실행 경로와 인수 조건을 연결한다.

## 내부 링크 정적 점검

기준본에서 `[[...]]` 링크 대상을 docs ID·파일 stem과 대조한 결과 **20곳이 `../Home`**을 사용한다. 현재 전처리는 `.md` 제거만 하며 `../`를 정규화하지 않는다. 이 대상은 정식 ID와 일치하지 않지만 현재 라우팅의 미등록 ID fallback이 Home을 보여 주므로 사용자가 홈 이동 실패를 반드시 겪는다는 뜻은 아니다.

후속 반영에서는 `[[Home|AI 계정 운영]]`처럼 실제 등록 ID를 쓰고, 기존 다른 링크의 렌더 결과도 확인한다. “20개 링크가 모두 깨졌다”라고 보고하지 않는다. 정적 점검에서 그 외 미등록 `[[...]]` 대상은 발견하지 못했다. 일반 Markdown 링크·실제 배포 경로·외부 URL까지 모두 검증했다는 의미는 아니다.

## 신규 문서 ID 제안

신규 문서를 필요 이상으로 쪼갤 필요는 없다. 현재 구조에 맞춰 합쳐도 되지만 G번호별 내용과 근거가 추적되어야 한다.

| 제안 ID (확장자 제외) | 주된 내용 | 자료 |
|---|---|---|
| `issues/Cursor_청구_크레딧_분쟁` | 비식별 사건과 원장 대조 절차 | 03, 13 |
| `issues/AI_서비스_장애_초동대응` | 오류·비용·계정 분류와 증거 | 03, 06, 14 |
| `billing/Colab_PAYG_결제_프로필` | 임시 권한·구매·증빙·회수 | 04 |
| `services/Colab_CU와_런타임_운영` | CU 원장·주기·런타임·미확인 조건 | 04–05 |
| `automation/Colab_Manager_운영` | 버전별 기능·복수 런타임 검수 | 05 |
| `automation/강의장_계정_초기화` | 삭제 범위·로그인·백업 버전 | 05 |
| `automation/비밀번호_교체` | v0.3 설계·민감 로그·재로그인 | 05, 08 |
| `automation/도구_배포와_검증` | 다운로드·서명·해시·현장 배포 | 05 |
| `billing/Claude_과금` | 좌석·갱신·API 별도 비용 | 06 |
| `operations/위키_유지보수` | 책임·개정·정적 자산·배포 확인 | 07–08, 12 |
| `templates/계정_운영_기록` | 운영 기록 양식 | 14 |
| `whitepaper/운영_연혁과_개선` | 실제 선택·결과·미확인 이력 | 02, 07, 13의 비식별 요약 |

## 새 문서 등록 절차

1. `public/content/<제안 ID>.md`를 작성한다. 내부 링크는 실제 ID를 사용한다.
2. `src/main.js`의 docs에 고유 id, title, file, group, summary를 등록한다.
3. sections의 해당 docIds에 추가한다. 새 group이면 실제 UI의 그룹 구성을 함께 검토한다.
4. Home·PAGE_TREE·_Sidebar·SOURCES와 서비스별 관련 문서를 연결한다.
5. quickTiles·serviceChips·priorityDocs는 목적에 맞는 항목만 수정한다. 모든 신규 문서를 홈 카드로 늘릴 필요는 없다.
6. 빌드 후 문서 목록·검색·직접 해시 링크·표·기록 양식을 확인한다.

## 후속 검증 기준

- 등록 ID·file 중복 없음, 등록 파일 존재, 새로운 위키 링크 대상 일치.
- `npm run build` 성공. 기준 저장소는 Node 24를 사용하는 배포 workflow를 갖고 있으므로 현재 환경과 lockfile을 확인한다.
- 새 그룹·문서의 목록·검색·직접 이동이 실제로 동작함.
- 출처·기준일·조건·미확인 표시 보존. 내부 자료를 공개 자산에 복사하지 않음.
- 배포가 별도로 요청되면 그때 실제 대상·권한·성공 결과를 확인함. 이 자료 작성 단계에서 배포를 수행했다고 보고하지 않음.

각 확인 파일의 Git blob SHA와 UTF-8 내용 SHA-256은 [source_manifest.json](source_manifest.json)에 기록한다.
