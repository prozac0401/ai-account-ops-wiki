# 출처와 확인 범위

확인일은 모두 2026-09-06 UTC다. R은 저장소, F는 보관 파일, C는 [대화 회수 목록](02_CONVERSATION_EVIDENCE.md), P는 현재 공식 문서를 뜻한다. 웹 문서는 원문 전체를 복제하지 않고 필요한 내용을 요약했다. 정책은 실제 반영일에 다시 확인한다.

## 저장소

| ID | 출처 | 확인 범위 |
|---|---|---|
| R01 | [기준 커밋](https://github.com/prozac0401/ai-account-ops-wiki/commit/a09570913697213fb34a95c62d0f0cae5864647a) | main HEAD, 커밋 시각, public/content Markdown 32개 |
| R02 | [src/main.js 기준본](https://github.com/prozac0401/ai-account-ops-wiki/blob/a09570913697213fb34a95c62d0f0cae5864647a/src/main.js) | docs/sections 명시 등록, 문서 fetch, 검색·탐색 구성 |
| R03 | [STYLE_GUIDE.md 기준본](https://github.com/prozac0401/ai-account-ops-wiki/blob/a09570913697213fb34a95c62d0f0cae5864647a/STYLE_GUIDE.md) | 한국어 문체, doc ID 링크, 제목·출처·빌드 검증 규칙 |

## 보관 파일

자료 항목은 22개이며 묶음 ZIP 내부 문서가 따로 늘어나는 수와 다르다. 해시는 [source_manifest.json](source_manifest.json)에 기록한다. ZIP의 내용은 설명서·설계서를 읽는 정적 조사만 했으며 실행 파일이나 스크립트를 실행하지 않았다. 원본 파일은 이 자료 묶음에 포함하지 않았다.

| ID | 자료 | 확인한 내용·한계 |
|---|---|---|
| F01 | `CLEAR_CURSOR_001.bat` | 개별 Cursor 보조 스크립트 자료; 실제 실행 결과 아님 |
| F02 | `CLEAR_CURSOR_STANDALONE_V3_001-042.zip` | V3 README, 비관리자·PowerShell 미사용·선택적 쿠키 정리·수동 앱 계정 확인 |
| F03 | `CURSOR_SEAT_LOGIN_001-042.zip` | 로그인 보조 README; 최종 계정 확인 필요 |
| F04 | `codex-prompt-cursor-password-rotation-v0.3.md` | 비밀번호 교체 요청·인수 조건 |
| F05 | `cursor-password-rotation-design-v0.3.md` | with-secrets 출력의 의도, 재로그인 검증·단계 확대 설계 |
| F06 | `B113_Colab_Manager_2026.08.11.1_Field_Test_Checklist.md` | V1/V2/V3 버전과 복수 런타임 게이트. 빈 체크리스트 |
| F07 | `B113_Colab_Manager_Codex_Spec.zip` | README·제품 사양·아키텍처·백로그·검수·수동 탐색·미해결 질문 등 설계 문서 |
| F08 | `B113_Colab_Card_Easy.zip` | 이전 카드 입력 도구 README; 현재 결제 프로필 공유 설계와 구분 |
| F09 | `Invoice-DTGSDZEF-0228.pdf` | 음수 총액과 Applied balance를 텍스트 및 마지막 페이지 렌더로 확인 |
| F10 | `Invoice-DTGSDZEF-0231.pdf` | 총액·Applied balance·Amount due |
| F11 | `Invoice-DTGSDZEF-0232.pdf` | 총액·Applied balance·Amount due |
| F12 | `Invoice-DTGSDZEF-0227.pdf` | 발행일·총액·Amount due |
| F13 | `Invoice-DTGSDZEF-0230.pdf` | 발행일·0달러 청구 표시 |
| F14 | `B113_Reset_00-48.zip` | 관리자 실행과 브라우저 초기화 범위 README |
| F15 | `Reset_README.txt` | Reset 배포 안내, 실행 범위 |
| F16 | `B113_Browser_Reset_README.txt` | 브라우저 초기화 안내; 다른 버전과 합쳐 추론하지 않음 |
| F17 | Google 지원 73730471, “Best practices for managing your payments profile” EML | 2026-07-27 01:14:11 UTC. Business/Organization, 초대 2주, 권한·primary contact 조건 |
| F18 | Google 지원 73730471, Workspace·Colab PAYG 설정 안내 EML | 2026-07-27 00:55:35 UTC. Google Pay → 결제 사용자 초대 → 수락·구매 흐름 |
| F19 | `1000035354.jpg` | Cursor Auto 설정 변경 전 화면(08:28), 이미지 직접 확인 |
| F20 | `1000035352.jpg` | Cursor Cost만 선택·Hard 선택 후 화면(08:31), 이미지 직접 확인; 저장·전파의 독립 증거 아님 |
| F21 | `ai_ot_agent_conversation_requirements_2026-08-18.md` | OT 에이전트 요구·키 관리·자료 처리 설계; 운영 결과 아님 |
| F22 | Google 지원 73730471, 한국어 문의 접수 확인 EML | 2026-07-26 23:43 UTC(7/27 KST). 접수 확인 내용만 열람. 상세 기술 답변으로 인용 금지. 장문 파일명으로 로컬 복사 실패, 본문 직접 열람 |

## 공식 문서

아래 표의 “사용 범위” 이상으로 정책을 확대하지 않는다. 실제 조직의 계약·계정 화면·과거 사건 결론을 공식 일반 문서만으로 확정할 수 없다.

| ID | 공식 출처 | 사용 범위 |
|---|---|---|
| P01 | [Cursor Teams pricing update, June 2026](https://cursor.com/blog/teams-pricing-june-2026) | Standard/Premium, 새 고객과 기존 갱신 적용 일정 |
| P02 | [Cursor Teams pricing](https://cursor.com/docs/account/teams/pricing) | 역할/좌석, 두 사용량 풀, on-demand, 좌석 증감·크레딧. 조직별 계약 확인 필요 |
| P03 | [Cursor spend limits](https://cursor.com/help/account-and-billing/spend-limits) | 설정 변경 권한, 팀/Enterprise 한도, 지연 집행·임시 크레딧 |
| P04 | [Cursor Router](https://cursor.com/docs/cursor-router) | Cost/Balance/Intelligence, Hard Auto, routed model 과금, Enterprise legacy 종료 경계 |
| P05 | [Cursor models and pricing](https://cursor.com/docs/models-and-pricing) | Max Mode의 legacy 범위, 모델·과금 구분 |
| P06 | [Cursor Token Rate](https://cursor.com/help/models-and-usage/token-rate) | 외부 모델 토큰 추가 요금과 적용 경로, Cursor Models 제외 |
| P07 | [Cursor Admin API](https://cursor.com/docs/account/teams/admin-api) | removed 멤버 표시, spendCents가 on-demand 금액이라는 범위. API를 실제 호출하지 않음 |
| P08 | [Google payments profile users](https://support.google.com/paymentscenter/answer/7162853?hl=en) | 검색·일부 내용 확인 후 재열람 제한. 절차의 직접 근거는 F17–F18을 우선 |
| P09 | [Manage users with individual Colab subscriptions](https://knowledge.workspace.google.com/admin/colab/manage-users-with-individual-colab-subscriptions) | 같은 계정의 조직·개인 CU 합산 및 개인 구독 관리 권한 경계 |
| P10 | [Assign Colab licenses to users](https://knowledge.workspace.google.com/admin/colab/assign-colab-licenses-to-users) | 서비스 활성화와 라이선스 별도, 활성화 지연. 해제 후 기존 CU 처리의 명시 답변 없음 |
| P11 | [Colab FAQ](https://research.google.com/colaboratory/faq.html) | 자원 비보장, 런타임·노트북 구분, CU 소진, 무료 제한 우회 금지 |
| P12 | [Colab 구매 화면](https://colab.research.google.com/signup) | 검색 결과에 CU 유효기간·양도 제한 안내. 본문 추출 제한으로 실제 상품별 checkout 재확인 필요 |
| P13 | [Cancel your Colab subscription](https://knowledge.workspace.google.com/admin/colab/cancel-your-colab-subscription) | 유료 구독 취소와 무료 서비스·다른 Workspace 서비스 구분. 기존 CU 소멸 여부로 확대 금지 |
| P14 | [ChatGPT and Codex pricing](https://learn.chatgpt.com/docs/pricing) | ChatGPT/Codex 포함, 추가 워크스페이스 크레딧, API key 비용 경로 구분. 조직별 신규/legacy 좌석 계약은 별도 확인 |
| P15 | [Codex enterprise admin setup](https://learn.chatgpt.com/docs/enterprise/admin-setup) | 조직 도입·접근·운영 틀 참고. Enterprise 절차를 Business에 동일 적용하지 않음 |
| P16 | [OpenAI API production best practices](https://developers.openai.com/api/docs/guides/production-best-practices) | 키·프로젝트 분리, spend alert와 hard limit 구분 |
| P17 | [OpenAI API spend limits](https://developers.openai.com/api/docs/guides/spend-limits) | 조직/프로젝트 hard limit, 429 코드, 집행 지연, 알림·usage tier와 차이 |
| P18 | [Azure Static Web Apps authentication and authorization](https://learn.microsoft.com/en-us/azure/static-web-apps/authentication-authorization) | 로그인과 허용 역할의 차이, 사전 설정 로그인 공급자 |
| P19 | [Azure Static Web Apps configuration](https://learn.microsoft.com/en-us/azure/static-web-apps/configuration) | 정적 파일 경로·allowedRoles·fallback 등 실제 서버 접근 제한 설정 |
| P20 | [Microsoft Unblock-File](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/unblock-file?view=powershell-7.5) | Zone.Identifier 제거의 의미. 서명·출처 신뢰성 검증을 대체하지 않음 |
| P21 | [Claude Team bill calculation](https://support.claude.com/en/articles/9267289-how-is-my-team-plan-bill-calculated) | 추가·업그레이드 일할 청구, 제거 시 즉시 환불 없음 |
| P22 | [Purchase and manage seats on Team plans](https://support.claude.com/en/articles/12004354-purchase-and-manage-seats-on-team-plans) | Owner의 total seat 변경, 갱신 반영, pending invite 집계 |
| P23 | [Claude subscription and API billing](https://support.claude.com/en/articles/9876003-i-have-a-paid-claude-subscription-pro-max-team-or-enterprise-plans-why-do-i-have-to-pay-separately-to-use-the-claude-api-and-console) | 유료 앱 구독과 API/Console의 별도 결제 |
| P24 | [Claude automatic model switching](https://support.claude.com/en/articles/15363606-why-claude-switched-models-in-your-conversation-with-fable-5-or-fable-5-1) | Fable 5/5.1 전환 설정·응답 라벨·과금 구분, 앱과 API fallback 차이 |

## 출처 사용 형식

위키 문장에는 적용일과 직접 관련 공식 링크를 붙인다. 현장 경험에는 F/C번호에 해당하는 내부 근거의 비식별 설명을 붙인다. 공개 페이지에는 개인 파일의 접근 토큰, 다운로드 URL, 내부 결제 프로필 ID를 싣지 않는다. 단순한 출처 목록만 두고 본문의 주장과 연결하지 않는 방식은 피한다.

공식 페이지 간 요금·메뉴·플랜 명칭이 충돌하면 계약 화면과 최신 문서의 적용 대상·시행일을 비교하고 충돌 자체를 기록한다. 요약 검색 결과만 확보한 P08/P12를 완전한 원문 확인으로 표시하지 않는다.
